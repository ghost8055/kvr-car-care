const CACHE_NAME = "kvr-car-care-v4";
const APP_SHELL = [
  "./index.html",
  "./owner.html",
  "./customer.html",
  "./manifest.webmanifest",
  "./manifest-owner.webmanifest",
  "./manifest-customer.webmanifest",
  "./assets/kvr-workshop.png",
  "./assets/kvr-signboard.png",
  "./assets/car-slide-1.svg",
  "./assets/car-slide-2.svg",
  "./assets/car-slide-3.svg",
  "./assets/kvr-app-icon.svg",
  "./assets/kvr-app-icon.png"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then(response => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put("./index.html", copy));
          }
          return response;
        })
        .catch(async () => (await caches.match(request)) || (await caches.match("./index.html")))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then(cached => cached || fetch(request).then(response => {
      if (response.ok) {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
      }
      return response;
    }))
  );
});
